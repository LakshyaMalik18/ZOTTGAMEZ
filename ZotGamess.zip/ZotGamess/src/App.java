import javax.swing.*;

public class App {
    public static void main(String[] args) {
        int boardWidth = 500;
        int boardHeight = 640;

        JFrame frame = new JFrame("ZotGames");
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Add ZotGames to JFrame
        ZotGames anteaterGame = new ZotGames();
        frame.add(anteaterGame);
        frame.pack();
        frame.setVisible(true);

        // Request focus correctly
        anteaterGame.requestFocusInWindow();
    }
}
